# Maozai (猫在) — fact sheet

**What it is:** a virtual pet kitten for iPhone and Apple Watch that lives through your day with you.
**App Store name:** Maozai: Your Pocket Cat
**Developer:** Will, independent developer in Los Angeles; formerly a software engineer at Tencent. Maozai is his first app.
**Released:** October 19, 2026 (version 1.0). Version 1.0.1 adds My Cats and six mystery-box breeds.
**Platforms:** iPhone (iOS 18 or later) and Apple Watch (watchOS 11 or later)
**Languages:** English, Simplified Chinese
**Price:** free to download; six kittens and every feature free. Optional Maozai Plus ($4.99/month or $29.99/year in the US) lifts the daily limit of 20 AI chat messages. Six more breeds in mystery boxes, $1.99 each; odds shown before purchase, no duplicates.
**Privacy:** no account, no ads, no tracking. Health data and the diary stay on the device. Chat goes to an AI language model only after the person agrees, is processed in the United States and is not stored.

## Features

- It gets hungry at your mealtimes and thirsty between them; "Eat together" answers with one tap.
- With permission it reads steps, exercise, heart rate and activity rings from Apple Health: it works out when you do, celebrates closed rings, and checks on you if your heart races while you sit still.
- It writes one diary line each night about the day you actually had.
- It answers briefly in chat, in character and in your language.
- Apple Watch: hold to pet, Digital Crown to tease, answer reminders with a tap.
- My Cats: switch between kittens any time; each keeps its own chats and diary.
- It never runs away or dies if you forget it.

## Art

The kitten images and video clips were generated with AI for this app.

## Links

- App Store: https://apps.apple.com/app/id6822157747
- Website: https://pocketcat.app
- Contact: wangweivei@gmail.com
